'use strict';
const vscode = require('vscode');
const core = require('./core');
const catalogue = require('./data/completions.json');

/** @param {import('vscode').ExtensionContext} context */
function activate(context) {
    const selector = { language: 'sage-x3-4gl' };
    const indexed = new Map(catalogue.map(item => [item.label.toUpperCase(), item]));
    const kinds = {
        function: vscode.CompletionItemKind.Function,
        variable: vscode.CompletionItemKind.Variable,
        type: vscode.CompletionItemKind.TypeParameter,
        keyword: vscode.CompletionItemKind.Keyword,
        constant: vscode.CompletionItemKind.Constant
    };
    function documentation(item) {
        const md = new vscode.MarkdownString();
        md.isTrusted = false;
        md.supportHtml = false;
        md.appendCodeblock(item.label, 'sage-x3-4gl');
        md.appendText((item.detail || 'Sage X3 4GL') + '\n\n');
        // Links here are static documentation links from the supplied catalogue.
        md.appendMarkdown(item.documentation || 'Identifiant du catalogue Sage X3 4GL.');
        return md;
    }
    context.subscriptions.push(vscode.languages.registerCompletionItemProvider(selector, {
        provideCompletionItems(document, position, cancellation) {
            if (cancellation.isCancellationRequested) return [];
            const line = document.lineAt(position.line).text;
            if (!core.isCodePosition(line, position.character)) return [];
            const prefix = core.completionPrefix(line, position.character);
            const token = core.tokenAt(line, position.character);
            const start = position.character - prefix.length;
            const end = token && token.start === start ? token.end : position.character;
            const replaceRange = new vscode.Range(position.line, start, position.line, end);
            const config = vscode.workspace.getConfiguration('sageX3', document.uri);
            const includeInternal = config.get('completions.includeInternal', true);
            const includeDeprecated = config.get('completions.includeDeprecated', true);
            const results = [];
            for (const entry of catalogue) {
                if (!core.allowedCompletion(entry, includeInternal, includeDeprecated)) continue;
                const item = new vscode.CompletionItem(entry.label, kinds[entry.kind] || vscode.CompletionItemKind.Keyword);
                item.detail = 'Sage X3 - ' + entry.detail;
                item.insertText = new vscode.SnippetString(entry.insertText);
                item.range = replaceRange;
                item.documentation = documentation(entry);
                item.sortText = (/interne|ancien|deprecated|conseille/i.test(entry.detail) ? '2_' : '1_') + entry.label.toUpperCase();
                results.push(item);
            }
            // Restrict local completion scanning to reasonably sized buffers.
            if (document.lineCount <= 20000 && !cancellation.isCancellationRequested) {
                const seen = new Set();
                for (const symbol of core.extractSymbols(document.getText())) {
                    const label = (symbol.kind === 'label' && prefix.startsWith('$') ? '$' : '') + symbol.name;
                    if (seen.has(label.toUpperCase()) || indexed.has(label.toUpperCase())) continue;
                    seen.add(label.toUpperCase());
                    const item = new vscode.CompletionItem(label, symbol.kind === 'label' ? vscode.CompletionItemKind.Reference : vscode.CompletionItemKind.Function);
                    item.insertText = label; // Literal insertion; labels do not become snippet variables.
                    item.range = replaceRange;
                    item.detail = 'Sage X3 - ' + (symbol.kind === 'label' ? 'Etiquette' : 'Routine') + ' du fichier courant';
                    item.sortText = '0_' + label.toUpperCase();
                    results.push(item);
                }
            }
            return results;
        }
    }, '$'));
    context.subscriptions.push(vscode.languages.registerHoverProvider(selector, {
        provideHover(document, position) {
            const line = document.lineAt(position.line).text;
            if (!core.isCodePosition(line, position.character)) return undefined;
            const token = core.tokenAt(line, position.character);
            const item = token && indexed.get(token.text.toUpperCase());
            if (!item) return undefined;
            return new vscode.Hover(documentation(item), new vscode.Range(position.line, token.start, position.line, token.end));
        }
    }));
    context.subscriptions.push(vscode.languages.registerDocumentSymbolProvider(selector, {
        provideDocumentSymbols(document, cancellation) {
            if (cancellation.isCancellationRequested) return [];
            const entries = core.extractSymbols(document.getText());
            return entries.map((entry, i) => {
                const lastLine = i + 1 < entries.length ? entries[i + 1].line - 1 : document.lineCount - 1;
                const range = new vscode.Range(entry.line, 0, lastLine, document.lineAt(lastLine).text.length);
                const selection = new vscode.Range(entry.line, entry.start, entry.line, entry.end);
                return new vscode.DocumentSymbol(
                    (entry.kind === 'label' ? '$' : '') + entry.name,
                    entry.kind === 'label' ? 'Etiquette 4GL' : 'Routine 4GL',
                    entry.kind === 'label' ? vscode.SymbolKind.Key : vscode.SymbolKind.Function,
                    range, selection
                );
            });
        }
    }));
}
function deactivate() {}
module.exports = { activate, deactivate };
