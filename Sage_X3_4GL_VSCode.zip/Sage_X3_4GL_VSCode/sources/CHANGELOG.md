# 1.1.0 - 2026-09-25

Conversion du package Sublime fourni vers VS Code et Notepad++.
Catalogue conserve, formats natifs et limites documentes.
