# Modeles Sage X3 4GL

Dans VS Code : saisir le prefixe (ou x3 + prefixe), Ctrl+Espace, choisir le snippet, puis Tab pour les champs.

| Prefixe / fichier | Usage |
|---|---|
| `action` | Sage X3 - Structure ACTION avec trois labels |
| `call` | Sage X3 - Call vers un Subprog externe |
| `calllocal` | Sage X3 - Call vers un Subprog du meme traitement |
| `case` | Sage X3 - Case / When / When Default |
| `classf` | Sage X3 - Reference de classe fichier |
| `classl` | Sage X3 - Reference de variable locale |
| `classm` | Sage X3 - Reference de classe masque |
| `classs` | Sage X3 - Reference de variable systeme |
| `classv` | Sage X3 - Reference de variable globale |
| `filter` | Sage X3 - Filtre sur une table ouverte |
| `for` | Sage X3 - Boucle numerique For / Next |
| `fordb` | Sage X3 - Parcourir une table ouverte |
| `forstep` | Sage X3 - Boucle numerique avec Step |
| `func` | Sage X3 - Appeler une fonction dans un autre traitement |
| `funprog` | Sage X3 - Funprog avec valeur de retour |
| `gosub` | Sage X3 - Appeler un label du meme traitement |
| `gosubfrom` | Sage X3 - Appeler un label dans un autre traitement |
| `if` | Sage X3 - If / Endif |
| `ifelse` | Sage X3 - If / Else / Endif |
| `label` | Sage X3 - Creer un label termine par Return |
| `labelannule` | Sage X3 - Label $ANNULE |
| `labelapres_cre` | Sage X3 - Label $APRES_CRE |
| `labelapres_mod` | Sage X3 - Label $APRES_MOD |
| `labelavant_cre` | Sage X3 - Label $AVANT_CRE |
| `labelavant_mod` | Sage X3 - Label $AVANT_MOD |
| `labelcreation` | Sage X3 - Label $CREATION |
| `labelferme` | Sage X3 - Label $FERME |
| `labelliens` | Sage X3 - Label $LIENS |
| `labelmodif` | Sage X3 - Label $MODIF |
| `labelouvre` | Sage X3 - Label $OUVRE |
| `labelrazcre` | Sage X3 - Label $RAZCRE |
| `labelverif` | Sage X3 - Label $VERIF |
| `localchar` | Sage X3 - Declaration Local Char |
| `localfile` | Sage X3 - Declaration Local File |
| `localint` | Sage X3 - Declaration Local Integer |
| `read` | Sage X3 - Lire un enregistrement et controler fstat |
| `repeat` | Sage X3 - Repeat / Until |
| `subprog` | Sage X3 - Subprog termine par End |
| `while` | Sage X3 - While / Wend |
