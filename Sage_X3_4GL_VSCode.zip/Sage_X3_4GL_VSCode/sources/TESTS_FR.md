# Verification du package - 25 septembre 2026

## Controles effectues

- Lecture de tous les JSON et XML generes, references internes et absence de BOM
  dans le fichier d'autocompletion Notepad++.
- Couverture de chaque nom du catalogue dans la grammaire VS Code et les listes
  UDL. Verification de plusieurs casses et des limites des identifiants.
- Compilation de 44 expressions de grammaire avec Python regex et Ruby Onigmo.
- Simulation lexicale independante : labels, definitions, appels, classes et
  champs, dates, fonctions avec $, commentaires et chaines.
- Verification du tri des 601 completions Notepad++, de leurs contraintes de
  nommage et des 19 definitions d'aide aux parametres.
- Verification de la conversion des 39 modeles : dollars litteraux conserves,
  aucune tabulation dynamique TextMate non resolue dans les fichiers .src.
- 1340 assertions Node : aides lexicales, listes de completion, metadonnees,
  activation et fournisseurs d'extension avec une API VS Code simulee.
- Inspection de l'archive VSIX : manifeste, identite/version, chemins des assets,
  fichiers requis et controle CRC des archives.

Le rapport validation-report.json donne les compteurs detailles.
Les sources de tests Node se trouvent dans sources/tests du ZIP VS Code.

## Ce que ces controles ne prouvent pas

Aucune fenetre VS Code, aucun extension host reel, aucun moteur TextMate de
VS Code et aucune instance Notepad++ n'ont ete executes dans cet environnement.
Ruby Onigmo et la simulation Python ne remplacent pas le test avec Oniguruma
et le moteur de l'editeur. Le lexer UDL n'a pas ete execute.
Le VSIX a ete assemble hors ligne, non signe, sans execution de vsce.
Aucun traitement n'a ete compile ou execute sur un serveur Sage X3.

## Verification manuelle conseillee apres installation

Ouvrir Exemple.src et controler le mode de langage, les commentaires contenant
#, les fonctions num$ et right$, $ACTION, [F:BPC]BPCNAM et les boucles.
Dans VS Code : inserer x3read via Ctrl+Espace, parcourir les champs avec Tab,
controler le survol d'un nom et le panneau Plan/Outline.
Dans Notepad++ : verifier le theme choisi, Ctrl+Espace apres nu et la completion
num$, puis l'aide aux parametres de find. Copier un modele du dossier Modeles.
