'use strict';

/** Pure lexical helpers. No filesystem, network, shell, or Sage runtime calls. */
function isCodePosition(line, column) {
    let quote = null;
    for (let i = 0; i < Math.min(column, line.length); i += 1) {
        const ch = line[i];
        if (quote !== null) {
            if (ch === quote) quote = null;
        } else if (ch === '#') {
            return false;
        } else if (ch === '"' || ch === "'") {
            quote = ch;
        }
    }
    return quote === null;
}

function tokenAt(line, column) {
    const expression = /\$?[A-Za-z_][A-Za-z0-9_]*\$?/g;
    let match;
    while ((match = expression.exec(line)) !== null) {
        if (column >= match.index && column <= match.index + match[0].length) {
            return { text: match[0], start: match.index, end: match.index + match[0].length };
        }
    }
    return null;
}

function completionPrefix(line, column) {
    const match = /[$A-Za-z_][A-Za-z0-9_$]*$/.exec(line.slice(0, column));
    return match ? match[0] : '';
}

/** Return explicitly declared dollar labels and routines; do not infer semantics. */
function extractSymbols(text) {
    const lines = text.split(/\r\n|\n|\r/);
    const found = [];
    for (let line = 0; line < lines.length; line += 1) {
        const value = lines[line];
        let match = /^\s*\$[ \t]*([A-Za-z_][A-Za-z0-9_]*)\b/.exec(value);
        let kind = 'label';
        if (!match) {
            match = /^\s*(?:Subprog|Funprog|Method)[ \t]+([A-Za-z_][A-Za-z0-9_]*)\b/i.exec(value);
            kind = 'function';
        }
        if (match) {
            const start = value.indexOf(match[1], kind === 'label' ? value.indexOf('$') + 1 : value.search(/\S/));
            found.push({ name: match[1], kind, line, start, end: start + match[1].length });
        }
    }
    return found;
}

function allowedCompletion(item, includeInternal, includeDeprecated) {
    const status = item.detail || '';
    if (!includeInternal && /interne|internal/i.test(status)) return false;
    if (!includeDeprecated && /ancien|d[e\u00e9]conseill[e\u00e9]|deprecated/i.test(status)) return false;
    return true;
}

module.exports = { isCodePosition, tokenAt, completionPrefix, extractSymbols, allowedCompletion };
