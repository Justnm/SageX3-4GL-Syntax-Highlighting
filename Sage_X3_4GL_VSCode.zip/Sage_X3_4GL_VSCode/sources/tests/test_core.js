'use strict';
const assert = require('assert/strict');
const fs = require('fs');
const path = require('path');
const core = require('../core');
let assertions = 0;
function eq(actual, expected) { assert.deepEqual(actual, expected); assertions++; }
function ok(value) { assert.ok(value); assertions++; }
const cases = [
    ['# num$', 6, false], ['T = "num$"', 7, false], ["T = 'num$'", 7, false],
    ['T = "#" + num$', 14, true], ['T = "ABC" # Comment', 15, false],
    ['Read [F:BPC]BPC0', 5, true], ['Gosub OUVRE', 11, true], ['T = "unterminated', 16, false]
];
for (const row of cases) eq(core.isCodePosition(row[0], row[1]), row[2]);
eq(core.tokenAt('X = num$(I)', 6), {text:'num$',start:4,end:8});
eq(core.tokenAt('$ACTION', 3).text, '$ACTION');
eq(core.tokenAt('[F:BPC]BPCNUM', 10).text, 'BPCNUM');
eq(core.completionPrefix('X = num', 7), 'num');
eq(core.completionPrefix('$', 1), '$');
eq(core.completionPrefix('Gosub ', 6), '');
eq(core.extractSymbols('# $NOT_LABEL\n$ACTION\n  Subprog ZTEST(A)\nFunprog ZFUNC(A)').map(x => x.name), ['ACTION','ZTEST','ZFUNC']);
eq(core.extractSymbols('Subprog Subprog2(A)')[0].start, 8);
eq(core.allowedCompletion({detail:'Interne'}, false, true), false);
eq(core.allowedCompletion({detail:'Ancien'}, true, false), false);
eq(core.allowedCompletion({detail:'Public'}, false, false), true);

const root = path.dirname(__dirname);
const completions = require('../data/completions.json');
eq(completions.length, 583);
eq(new Set(completions.map(x => x.label.toUpperCase())).size, 583);
for (const item of completions) {
    ok(typeof item.insertText === 'string' && item.insertText.length > 0);
    ok(typeof item.documentation === 'string');
}
for (const name of ['num$','date$','right$','left$','find','type','GUSER','GACTX','GERR','GFONCTION']) {
    ok(completions.find(item => item.label === name));
}
const snippetJson = require('../snippets/sage-x3-4gl.json');
eq(Object.keys(snippetJson).length, 39);
for (const item of Object.values(snippetJson)) {
    eq(item.prefix.length, 2);
    ok(item.prefix[1].startsWith('x3'));
    ok(Array.isArray(item.body));
}
const config = require('../language-configuration.json');
new RegExp(config.wordPattern); assertions++;
for (const expression of Object.values(config.indentationRules)) { new RegExp(expression); assertions++; }
for (const expression of Object.values(config.folding.markers)) { new RegExp(expression); assertions++; }
const pkg = require('../package.json');
for (const name of [pkg.main, ...pkg.contributes.grammars.map(x=>x.path), ...pkg.contributes.snippets.map(x=>x.path), pkg.contributes.languages[0].configuration]) {
    ok(fs.existsSync(path.join(root, name)));
}

// Exercise the real extension with a small API mock. This is NOT a VS Code UI test.
const registered = {};
class Range { constructor(a,b,c,d) { this.start={line:a,character:b}; this.end={line:c,character:d}; } }
class MarkdownString {
    constructor() { this.value=''; }
    appendText(s) { this.value+=s; return this; }
    appendCodeblock(s) { this.value+=s+'\n'; return this; }
    appendMarkdown(s) { this.value+=s; return this; }
}
class CompletionItem { constructor(label,kind) { this.label=label; this.kind=kind; } }
class SnippetString { constructor(value) { this.value=value; } }
class Hover { constructor(contents,range) { this.contents=contents; this.range=range; } }
class DocumentSymbol { constructor(name,detail,kind,range,selectionRange) { Object.assign(this,{name,detail,kind,range,selectionRange}); } }
let includeInternal = true;
const mock = {
    Range, MarkdownString, CompletionItem, SnippetString, Hover, DocumentSymbol,
    CompletionItemKind: {Function:3,Variable:6,TypeParameter:25,Keyword:14,Constant:21,Reference:18},
    SymbolKind: {Key:20,Function:12},
    workspace: {getConfiguration: () => ({get: (key,fallback) => key === 'completions.includeInternal' ? includeInternal : fallback})},
    languages: {
        registerCompletionItemProvider: (s,p) => { registered.completion=p; return {dispose(){}}; },
        registerHoverProvider: (s,p) => { registered.hover=p; return {dispose(){}}; },
        registerDocumentSymbolProvider: (s,p) => { registered.symbol=p; return {dispose(){}}; }
    }
};
const Module = require('module');
const originalLoad = Module._load;
Module._load = function(request, ...args) { return request === 'vscode' ? mock : originalLoad.call(this,request,...args); };
const extension = require('../extension');
Module._load = originalLoad;
const context = {subscriptions:[]};
extension.activate(context);
eq(context.subscriptions.length,3);
function doc(text) {
    const lines=text.split('\n');
    return {uri:{scheme:'untitled'},lineCount:lines.length,lineAt:i=>({text:lines[i]}),getText:()=>text};
}
const cancellation = {isCancellationRequested:false};
let results=registered.completion.provideCompletionItems(doc('num'),{line:0,character:3},cancellation);
eq(results.length,583);
eq(results.find(x=>x.label==='num$').insertText.value, 'num\\$(${1:VALEUR})');
eq(results.find(x=>x.label==='date$').insertText.value, 'date\\$');
eq(registered.completion.provideCompletionItems(doc('# num'),{line:0,character:5},cancellation),[]);
eq(registered.completion.provideCompletionItems(doc('X="num'),{line:0,character:6},cancellation),[]);
results=registered.completion.provideCompletionItems(doc('$OUVRE\nReturn\nGosub O'),{line:2,character:7},cancellation);
ok(results.find(x=>x.label==='OUVRE'));
results=registered.completion.provideCompletionItems(doc('$OUVRE\nReturn\n$'),{line:2,character:1},cancellation);
eq(results.find(x=>x.label==='$OUVRE').insertText,'$OUVRE');
results=registered.completion.provideCompletionItems(doc('num$'),{line:0,character:2},cancellation);
eq(results.find(x=>x.label==='num$').range.end.character,4);
const hover=registered.hover.provideHover(doc('NUM$(I)'),{line:0,character:2});
ok(hover.contents.value.includes('num$'));
eq(hover.contents.isTrusted,false);
eq(registered.hover.provideHover(doc('# num$'),{line:0,character:4}),undefined);
const symbols=registered.symbol.provideDocumentSymbols(doc('$ACTION\nReturn\nSubprog ZTEST(A)\nEnd'),cancellation);
eq(symbols.map(x=>x.name),['$ACTION','ZTEST']);
includeInternal=false;
results=registered.completion.provideCompletionItems(doc(''),{line:0,character:0},cancellation);
ok(!results.some(x=>x.label==='actihgup'));
ok(results.some(x=>x.label==='num$'));
console.log(JSON.stringify({passed:true,assertions,testMode:'Node unit tests plus mocked VS Code API; no editor UI execution'}));
