# Catalogue Sage X3 4GL

Instantané documentaire : 2026-09-25.

Les noms sont dédupliqués sans tenir compte de la casse. Les catégories peuvent se chevaucher.

| Mot / expression | Catégorie(s) | Statut(s) |
|---|---|---|
| `abs` | Fonction | Public |
| `ach` | Fonction | Public |
| `acos` | Fonction | Public |
| `actihgup` | Variable / methode moteur | Internal |
| `Actzo` | Instruction | Deprecated |
| `Additm` | Instruction | Deprecated |
| `Addmen` | Instruction | Deprecated |
| `addmonth` | Fonction | Public |
| `adxcio` | Fonction | Internal |
| `adxcpw` | Variable / methode moteur | Internal |
| `adxctx` | Variable / methode moteur | Internal |
| `adxcus` | Variable / methode moteur | Internal |
| `adxdbc` | Variable / methode moteur | Internal |
| `adxdbo` | Variable / methode moteur | Internal |
| `adxdbx` | Variable / methode moteur | Internal |
| `adxdcs` | Variable / methode moteur | Public |
| `adxdir` | Variable / methode moteur | Public |
| `adxdlrec` | Variable / methode moteur | Public |
| `adxdpg` | Variable / methode moteur | Internal |
| `adxfmt` | Variable / methode moteur | Internal |
| `adxfname` | Variable / methode moteur | Public |
| `adxftl` | Variable / methode moteur | Public |
| `adxgtb` | Variable / methode moteur | Deprecated |
| `adxifs` | Variable / methode moteur | Public |
| `adxioa` | Fonction | Internal |
| `adxirs` | Variable / methode moteur | Public |
| `adxium` | Variable / methode moteur | Public |
| `adxkpg` | Variable / methode moteur | Deprecated |
| `adxksp` | Variable / methode moteur | Deprecated |
| `adxlig` | Variable / methode moteur | Deprecated |
| `adxlog` | Variable / methode moteur | Public |
| `adxmac` | Fonction | Public |
| `adxmbm` | Variable / methode moteur | Internal |
| `adxmda` | Variable / methode moteur | Public |
| `adxmother` | Variable / methode moteur | Public |
| `adxmpgpro` | Variable / methode moteur | Deprecated |
| `adxmpgtrt` | Variable / methode moteur | Deprecated |
| `adxmpr` | Variable / methode moteur | Internal |
| `adxmso` | Variable / methode moteur | Internal |
| `adxmto` | Variable / methode moteur | Internal |
| `adxmua` | Variable / methode moteur | Deprecated |
| `adxmxl` | Variable / methode moteur | Deprecated |
| `adxnfs` | Fonction | Internal |
| `adxovf` | Variable / methode moteur | Internal |
| `adxovs` | Variable / methode moteur | Internal |
| `adxpam` | Fonction | Deprecated |
| `adxpid` | Fonction | Internal |
| `adxpno` | Fonction | Public |
| `adxrob` | Variable / methode moteur | Deprecated |
| `adxsax` | Variable / methode moteur | Internal |
| `adxsca` | Variable / methode moteur | Internal |
| `adxseek` | Fonction | Public |
| `adxses` | Variable / methode moteur | Internal |
| `adxsqlrec` | Variable / methode moteur | Public |
| `adxtcp` | Fonction | Public |
| `adxtct` | Variable / methode moteur | Public |
| `adxtlk` | Variable / methode moteur | Public |
| `adxtms` | Variable / methode moteur | Public |
| `adxtrl` | Variable / methode moteur | Internal |
| `adxtro` | Variable / methode moteur | Internal |
| `adxtrp` | Variable / methode moteur | Internal |
| `adxtuc` | Variable / methode moteur | Internal |
| `adxtul` | Variable / methode moteur | Internal |
| `adxtut` | Variable / methode moteur | Internal |
| `adxtyp` | Fonction | Internal |
| `adxuid` | Fonction | Public |
| `adxuprec` | Variable / methode moteur | Public |
| `adxusr` | Variable / methode moteur | Internal |
| `adxwrb` | Variable / methode moteur | Public |
| `Affzo` | Instruction | Deprecated |
| `allocgrp` | Fonction | New |
| `Anasql` | Instruction | Public |
| `and` | Fonction | Public |
| `anp` | Fonction | Public |
| `Append` | Instruction | New |
| `ar2` | Fonction | Public |
| `arr` | Fonction | Public |
| `As` | Instruction | Public |
| `Asc` | Instruction | Public |
| `ascii` | Fonction | Public |
| `ash` | Fonction | Public |
| `asin` | Fonction | Public |
| `Askui` | Instruction | Deprecated Classic |
| `Assign` | Instruction | Public |
| `At` | Instruction | Deprecated |
| `atan` | Fonction | Public |
| `atan2` | Fonction | Public |
| `ath` | Fonction | Public |
| `avg` | Fonction | Public |
| `aweek` | Fonction | Public |
| `b64decode` | Fonction | New |
| `b64encode` | Fonction | New |
| `Blbfile` | Instruction | Public |
| `Blk` | Instruction | Deprecated |
| `Boolean` | Instruction | Documented supplement |
| `Boxact` | Instruction | Deprecated |
| `Boxclr` | Instruction | Deprecated |
| `Boxinp` | Instruction | Deprecated |
| `Break` | Instruction | Public |
| `Button` | Instruction | Deprecated |
| `By` | Instruction | Public |
| `Call` | Instruction | Public |
| `Callilog` | Instruction | Deprecated |
| `Calliu` | Instruction | Deprecated |
| `Callmet` | Instruction | Internal |
| `Callocx` | Instruction | Deprecated Classic |
| `callstack` | Fonction | Internal |
| `Callui` | Instruction | Deprecated |
| `Callws` | Instruction | Deprecated |
| `Case` | Instruction | Public |
| `cast` | Fonction | New |
| `ch` | Fonction | Public |
| `Chain` | Instruction | Deprecated |
| `Char` | Instruction | Public |
| `Checkin` | Instruction | Internal |
| `checkpath` | Fonction | New |
| `Chgfmt` | Instruction | Deprecated |
| `Chgstl` | Instruction | Deprecated |
| `Chgtbk` | Instruction | Deprecated |
| `Chgtfd` | Instruction | Deprecated |
| `Chgtzn` | Instruction | Deprecated |
| `Choose` | Instruction | Deprecated |
| `chr$` | Fonction | Public |
| `clacmp` | Fonction | Public |
| `clactxnbs` | Fonction | Internal |
| `clactxvar` | Fonction | Internal |
| `clalev` | Fonction | Public |
| `clanam` | Fonction | Public |
| `clanbs` | Fonction | Public |
| `clasiz` | Fonction | Public |
| `clavar` | Fonction | Public |
| `Clbfile` | Instruction | Public |
| `Clldap` | Instruction | Deprecated |
| `clone` | Fonction | Internal |
| `Close` | Instruction | Public |
| `Closecom` | Instruction | Internal |
| `closelog` | Fonction | Public |
| `CloseXml` | Instruction | Internal |
| `cnp` | Fonction | Public |
| `Coded` | Instruction | Internal |
| `Columns` | Instruction | Public |
| `Commit` | Instruction | Public |
| `compressfiles` | Fonction | Documented supplement |
| `Const` | Instruction | Public |
| `Contains$` | Instruction | Public |
| `Convxml` | Instruction | Internal |
| `cop$` | Fonction | Deprecated |
| `copfile` | Fonction / Instruction | Public / Documented supplement |
| `cos` | Fonction | Public |
| `ctrans` | Fonction | Public |
| `ctxinfo` | Variable / methode moteur | Deprecated |
| `Curr` | Instruction | Public |
| `currbox` | Variable / methode moteur | Deprecated |
| `currind` | Variable / methode moteur | Public |
| `currlen` | Variable / methode moteur | Public |
| `Date` | Instruction | Public |
| `date$` | Fonction | Public |
| `datesyst` | Variable / methode moteur | Internal |
| `Datetime` | Instruction | Public |
| `datetime$` | Fonction | New |
| `day` | Fonction | Public |
| `day$` | Fonction | Public |
| `dayn` | Fonction | Public |
| `Dbgaff` | Instruction | Public |
| `Dbgattach` | Instruction | Internal |
| `Dbgbox` | Instruction | Deprecated |
| `dbgbreakpointadd` | Fonction | Internal |
| `dbgbreakpointget` | Fonction | Internal |
| `dbgbreakpointlist` | Fonction | Internal |
| `Dbgbreakpointremove` | Fonction | Internal |
| `Dbgbreakpointupdate` | Fonction | Internal |
| `Dbgcallstack` | Instruction | Internal |
| `dbgduration` | Variable / methode moteur | Internal |
| `dbgevalue` | Fonction | Internal |
| `dbgevalue2` | Fonction | Internal |
| `dbgexcept` | Variable / methode moteur | Internal |
| `dbglineoffset` | Variable / methode moteur | Internal |
| `dbglog` | Variable / methode moteur | Internal |
| `dbglong` | Variable / methode moteur | Internal |
| `dbgmode` | Variable / methode moteur | Public |
| `dbgstr` | Variable / methode moteur | Internal |
| `dclkey` | Variable / methode moteur | Deprecated |
| `Decimal` | Instruction | Public |
| `Default` | Instruction | Public |
| `Dela` | Instruction | Public |
| `Delete` | Instruction | Public |
| `Deletebykey` | Instruction | New |
| `delfile` | Fonction / Instruction | Public / Documented supplement |
| `Desc` | Instruction | Public |
| `dim` | Fonction | Public |
| `dimctx` | Fonction | Internal |
| `dir$` | Fonction | Public |
| `Disable` | Instruction | Deprecated |
| `Discombo` | Instruction | Deprecated |
| `Dislbox` | Instruction | Deprecated |
| `Diszo` | Instruction | Deprecated |
| `Dlgbox` | Instruction | Deprecated |
| `Double` | Instruction | Public |
| `Dspzo` | Instruction | Deprecated |
| `Edi` | Instruction | Deprecated Classic |
| `Effzo` | Instruction | Deprecated |
| `Else` | Instruction | Public |
| `Elsif` | Instruction | Public |
| `Enable` | Instruction | Deprecated |
| `End` | Instruction | Public |
| `Endbox` | Instruction | Deprecated |
| `Endcase` | Instruction | Public |
| `Endif` | Instruction | Public |
| `entete` | Fonction | Deprecated |
| `Envzo` | Instruction | Deprecated |
| `eomonth` | Fonction | Public |
| `Errbox` | Instruction | Deprecated |
| `errl` | Fonction | Public |
| `errm` | Fonction | Public |
| `errmes$` | Fonction | Public |
| `errn` | Fonction | Public |
| `errnremote` | Fonction | Internal |
| `errp` | Fonction | Public |
| `escjson` | Fonction | Public |
| `evalue` | Fonction | Public |
| `evaluesdata` | Fonction | Public |
| `Execsql` | Instruction | Public |
| `Execws` | Instruction | Deprecated |
| `exp` | Fonction | Public |
| `Extended` | Instruction | Public |
| `Extern` | Instruction | Deprecated |
| `extsize` | Variable / methode moteur | New |
| `fac` | Fonction | Public |
| `FALSE` | Constante | Documented supplement |
| `Field` | Instruction | Deprecated |
| `filcom` | Fonction | Internal |
| `File` | Instruction | Public |
| `fileabre` | Variable / methode moteur | Internal |
| `filecla` | Fonction | Internal |
| `filelev` | Fonction | Internal |
| `filename` | Variable / methode moteur | Internal |
| `filenume` | Variable / methode moteur | Internal |
| `filetyp` | Fonction | Internal |
| `filexist` | Fonction | Public |
| `filinfo` | Fonction | Public |
| `Fillbox` | Instruction | Deprecated |
| `filpath` | Fonction | Public |
| `Filter` | Instruction | Public |
| `find` | Fonction | Public |
| `First` | Instruction | Public |
| `fix` | Fonction | Public |
| `Float` | Instruction | Public |
| `Flush` | Instruction | Public |
| `fmet` | Fonction | New |
| `Fmethod` | Instruction | New |
| `Folder` | Instruction | Deprecated |
| `For` | Instruction | Public |
| `format$` | Fonction | Public |
| `Formula` | Instruction | Deprecated |
| `FreeGroup` | Instruction | New |
| `freeheap` | Fonction | Public |
| `FreeInstance` | Instruction | New |
| `freemem` | Fonction | Public |
| `freesnapshot` | Fonction | New |
| `freesyssnapshot` | Fonction | Internal |
| `From` | Instruction | Public |
| `fstat` | Variable / methode moteur | Public |
| `func` | Fonction | Public |
| `funciu` | Fonction | Deprecated |
| `Funprog` | Instruction | Public |
| `gdat$` | Fonction | Public |
| `gdatetime$` | Fonction | Public |
| `getaccessorenabled` | Variable / methode moteur | New |
| `getBit` | Fonction | Public |
| `GetChildByName` | Instruction | Internal |
| `GetChildByType` | Instruction | Internal |
| `getenv$` | Fonction | Public |
| `GetFirstChild` | Instruction | Internal |
| `GetFirstChildByName` | Instruction | Internal |
| `GetLastChild` | Instruction | Internal |
| `GetLastChildByName` | Instruction | Internal |
| `getlogname` | Fonction | Public |
| `getmodified` | Fonction | New |
| `GetNbChild` | Instruction | Internal |
| `GetNextChild` | Instruction | Internal |
| `GetNextChildByName` | Instruction | Internal |
| `GetParent` | Instruction | Internal |
| `GetRootElement` | Instruction | Internal |
| `Getseq` | Instruction | Public |
| `getsysmodified` | Fonction | Internal |
| `Getui` | Instruction | Deprecated |
| `Getuuid` | Fonction | New |
| `Global` | Instruction | Public |
| `Gosub` | Instruction | Public |
| `Goto` | Instruction | Public |
| `graph$` | Fonction | Deprecated |
| `Grizo` | Instruction | Deprecated |
| `heapdmp` | Fonction | Public |
| `Hint` | Instruction | Public |
| `Hlpbox` | Instruction | Deprecated |
| `If` | Instruction | Public |
| `Image` | Instruction | Deprecated |
| `indcum` | Variable / methode moteur | Public |
| `indice` | Variable / methode moteur | Deprecated |
| `Infbox` | Instruction | Deprecated |
| `Infimg` | Instruction | Deprecated |
| `Inftxt` | Instruction | Deprecated |
| `Inpbox` | Instruction | Deprecated |
| `inpmode` | Fonction | Deprecated |
| `Insa` | Instruction | Public |
| `Insli` | Instruction | Deprecated |
| `Instance` | Instruction | New |
| `instr` | Fonction | Public |
| `int` | Fonction | Public |
| `Integer` | Instruction | Public |
| `Inter` | Instruction | Internal |
| `Invfol` | Instruction | Deprecated |
| `Iomode` | Instruction | Public |
| `isomess` | Variable / methode moteur | Internal |
| `IsOpenAdxd` | Fonction | Internal |
| `isreadonly` | Variable / methode moteur | New |
| `jsonproto` | Fonction | Internal |
| `Key` | Instruction | Public |
| `keylen` | Variable / methode moteur | Deprecated |
| `keyname` | Variable / methode moteur | Deprecated |
| `keyuniq` | Variable / methode moteur | Deprecated |
| `Kill` | Instruction | Public |
| `Last` | Instruction | Public |
| `left$` | Fonction | Public |
| `Leftbox` | Instruction | Deprecated |
| `len` | Fonction | Public |
| `Libelle` | Instruction | Deprecated |
| `Link` | Instruction | Public |
| `Listbox` | Instruction | Deprecated |
| `Listimp` | Instruction | Deprecated |
| `ln` | Fonction | Public |
| `lobsize` | Fonction | Public |
| `Local` | Instruction | Public |
| `locfshost` | Variable / methode moteur | Deprecated |
| `locfsqon` | Variable / methode moteur | Deprecated |
| `locfsqport` | Variable / methode moteur | Deprecated |
| `Lock` | Instruction | Public |
| `lockwait` | Variable / methode moteur | Public |
| `log` | Fonction | Public |
| `LogicClose` | Instruction | Public |
| `Look` | Instruction | Public |
| `Mask` | Instruction | Deprecated |
| `maskabr` | Fonction | Deprecated |
| `maskcla` | Fonction | Deprecated |
| `maskcou` | Fonction | Deprecated |
| `masklev` | Fonction | Deprecated |
| `masknam` | Fonction | Deprecated |
| `masknbf` | Fonction | Deprecated |
| `maskrk` | Fonction | Deprecated |
| `masksiz` | Fonction | Deprecated |
| `max` | Fonction | Public |
| `maxheap` | Variable / methode moteur | Internal |
| `maxmem` | Variable / methode moteur | Internal |
| `Maxrows` | Instruction | Deprecated |
| `maxtab` | Fonction | New |
| `Men` | Instruction | Deprecated |
| `menchoix` | Variable / methode moteur | Deprecated |
| `Mesbox` | Instruction | Deprecated |
| `mess` | Fonction | Public |
| `messname` | Variable / methode moteur | Internal |
| `Method` | Instruction | New / Internal |
| `mid$` | Fonction | Public |
| `min` | Fonction | Public |
| `mkstat` | Variable / methode moteur | Deprecated |
| `mod` | Fonction | Public |
| `modified` | Fonction | New |
| `month` | Fonction | Public |
| `month$` | Fonction | Public |
| `movfile` | Fonction / Instruction | Public / Documented supplement |
| `Nap` | Instruction | Deprecated |
| `nbind` | Variable / methode moteur | Public |
| `nbrecord` | Fonction | Public |
| `nbruser` | Fonction | Internal |
| `nbzon` | Variable / methode moteur | Public |
| `nday` | Fonction | Public |
| `nday$` | Fonction | Public |
| `NewInstance` | Instruction / Fonction | New |
| `Next` | Instruction | Public |
| `Nohint` | Instruction | Public |
| `Nointer` | Instruction | Internal |
| `nolign` | Variable / methode moteur | Deprecated |
| `nolign1` | Variable / methode moteur | Deprecated |
| `nomap` | Variable / methode moteur | Public |
| `not` | Fonction | Public |
| `Null` | Fonction | New |
| `Nulluuid` | Fonction | New |
| `num$` | Fonction | Public |
| `Nxldap` | Instruction | Deprecated |
| `Nxt` | Instruction | Deprecated |
| `objectexist` | Fonction | Public |
| `objectnbs` | Fonction | Public |
| `objecttype` | Fonction | Public |
| `objectvar` | Fonction | Public |
| `Onerrgo` | Instruction | Public |
| `Onevent` | Instruction | Deprecated |
| `Onintgo` | Instruction | Internal |
| `Onkey` | Instruction | Deprecated |
| `Opadxd` | Instruction | Internal |
| `Openi` | Instruction | Public |
| `Openio` | Instruction | Public |
| `openlog` | Fonction | Public |
| `Openo` | Instruction | Public |
| `Opldap` | Instruction | Internal |
| `Opsock` | Instruction | Internal |
| `or` | Fonction | Public |
| `Order By` | Instruction | Public |
| `parse` | Fonction | Public |
| `ParseInstance` | Instruction | Public |
| `password` | Variable / methode moteur | Deprecated |
| `pat` | Fonction | Public |
| `pcolor` | Variable / methode moteur | Deprecated |
| `pi` | Fonction | Public |
| `Pick` | Instruction | Deprecated |
| `Pickbox` | Instruction | Deprecated |
| `Pikltb` | Instruction | Deprecated |
| `Pmt` | Instruction | Deprecated Classic |
| `Pokltb` | Instruction | Deprecated |
| `prd` | Fonction | Public |
| `Prev` | Instruction | Public |
| `progcan` | Fonction | Internal |
| `progldd` | Fonction | Internal |
| `progsiz` | Fonction | Internal |
| `progusd` | Fonction | Internal |
| `pullobject` | Fonction | Internal |
| `pullscript` | Fonction | Internal |
| `pushscript` | Fonction | Internal |
| `Putseq` | Instruction | Public |
| `Qstbox` | Instruction | Deprecated |
| `Raz` | Instruction | Public |
| `Rdseq` | Instruction | Public |
| `Read` | Instruction | Public |
| `Readlock` | Instruction | Public |
| `Reb` | Instruction | Deprecated |
| `reckey` | Variable / methode moteur | Public |
| `RenameFile` | Instruction / Fonction | New |
| `Repeat` | Instruction | Public |
| `Report` | Instruction | Internal |
| `Resume` | Instruction | Public |
| `Return` | Instruction | Public |
| `reverttosnapshot` | Fonction | New |
| `reverttosyssnaphot` | Fonction | Internal |
| `revertupdtick` | Fonction | New |
| `Rewrite` | Instruction | Public |
| `Rewritebykey` | Instruction | New |
| `right$` | Fonction | Public |
| `rnd` | Fonction | Public |
| `Rollback` | Instruction | Public |
| `rowcount` | Fonction | Public |
| `Rptfile` | Instruction | Internal |
| `Rptstat` | Instruction | Internal |
| `Run` | Instruction | Internal |
| `sadmem` | Variable / methode moteur | Internal |
| `Saizo` | Instruction | Deprecated |
| `Saxparse` | Instruction | Internal |
| `Schar` | Instruction | Public |
| `secmod` | Variable / methode moteur | Deprecated |
| `Seek` | Instruction | Public |
| `seg$` | Fonction | Public |
| `Seldest` | Instruction | Deprecated Classic |
| `Select$` | Instruction | Public |
| `Selimp` | Instruction | Deprecated |
| `Send` | Instruction | Deprecated Classic |
| `setaccessorenabled` | Variable / methode moteur | New |
| `setBit` | Fonction | Public |
| `Setcod` | Instruction | Deprecated |
| `Setfct` | Instruction | Internal |
| `Setgus` | Instruction | Internal |
| `SetInstance` | Instruction | New |
| `SetInstancenosys` | Instruction | Documented supplement |
| `Setlbox` | Instruction | Deprecated |
| `Setlob` | Instruction | Public |
| `Setmdu` | Instruction | Internal |
| `Setmode` | Instruction | Deprecated |
| `Setmok` | Instruction | Deprecated |
| `sgn` | Fonction | Public |
| `sh` | Fonction | Public |
| `Shortint` | Instruction | Public |
| `sigma` | Fonction | Public |
| `sin` | Fonction | Public |
| `Sized` | Instruction | Deprecated |
| `Sleep` | Instruction | Public |
| `snapshot` | Variable / methode moteur | New |
| `snapshotenabled` | Variable / methode moteur | New |
| `Sorta` | Instruction | Public |
| `space$` | Fonction | Public |
| `Sql` | Instruction | Public |
| `sqr` | Fonction | Public |
| `Srldapbs` | Instruction | Deprecated |
| `Srldaplv` | Instruction | Deprecated |
| `Srldaptr` | Instruction | Deprecated |
| `Ssl` | Instruction | Deprecated |
| `Stability` | Instruction | Public |
| `Starting` | Instruction | Deprecated |
| `stat1` | Variable / methode moteur | Public |
| `status` | Variable / methode moteur | Deprecated |
| `Step` | Instruction | Public |
| `strdecode` | Fonction | New |
| `strencode` | Fonction | New |
| `string$` | Fonction | Public |
| `Subprog` | Instruction | Public |
| `sum` | Fonction | Public |
| `Supli` | Instruction | Deprecated |
| `Syrrecv` | Instruction | Internal |
| `Syrsend` | Instruction | Internal |
| `sysmodified` | Fonction | Internal |
| `syssnapshot` | Variable / methode moteur | Internal |
| `syssnapshotenabled` | Variable / methode moteur | Internal |
| `System` | Instruction | Public |
| `tab$` | Fonction | Deprecated |
| `tairec` | Variable / methode moteur | Public |
| `tan` | Fonction | Public |
| `th` | Fonction | Public |
| `Then` | Instruction | Public |
| `this` | Variable / methode moteur | New |
| `Throwerr` | Instruction | Deprecated |
| `time` | Fonction | Public |
| `time$` | Fonction | Public |
| `timestamp$` | Fonction | Public |
| `Timeval` | Instruction | Deprecated |
| `Tinyint` | Instruction | New |
| `Titcol` | Instruction | Deprecated |
| `Titled` | Instruction | Deprecated |
| `titre` | Variable / methode moteur | Deprecated |
| `To` | Instruction | Public |
| `tolower` | Fonction | Public |
| `toSData` | Fonction | Public |
| `toupper` | Fonction | Public |
| `touuid` | Fonction | New |
| `Transmask` | Instruction | Deprecated |
| `Trbegin` | Instruction | Public |
| `Treebox` | Instruction | Deprecated |
| `trtcou` | Fonction | Public |
| `TRUE` | Constante | Documented supplement |
| `type` | Fonction | Public |
| `typectx` | Fonction | Internal |
| `unescjson` | Fonction | Public |
| `uni` | Fonction | Public |
| `uniqid` | Fonction | Public |
| `Unlock` | Instruction | Public |
| `Until` | Instruction | Public |
| `Update` | Instruction | Public |
| `updtick` | Variable / methode moteur | New |
| `Using` | Instruction | Public |
| `uuid$` | Fonction | New |
| `Uuident` | Instruction | New |
| `val` | Fonction | Public |
| `Value` | Instruction | Public |
| `var` | Fonction | Public |
| `Variable` | Instruction | Public |
| `varinit` | Fonction | Deprecated |
| `varmode` | Fonction | Deprecated |
| `Vbcall` | Instruction | Deprecated |
| `ver$` | Fonction | Public |
| `vireblc` | Fonction | Public |
| `week` | Fonction | Public |
| `Wend` | Instruction | Public |
| `When` | Instruction | Public |
| `Where` | Instruction | Public |
| `While` | Instruction | Public |
| `With` | Instruction | Public |
| `Write` | Instruction | Public |
| `Writeb` | Instruction | New |
| `Wrnbox` | Instruction | Deprecated |
| `Wrseq` | Instruction | Public |
| `xgetchar` | Fonction | New |
| `xor` | Fonction | Public |
| `year` | Fonction | Public |
| `zc` | Variable / methode moteur | Deprecated |
| `zoncou` | Variable / methode moteur | Deprecated |
| `zonsor` | Variable / methode moteur | Deprecated |
| `zonsui` | Variable / methode moteur | Deprecated |
