# Sage X3 4GL pour VS Code

Version 1.1.0 - package local non officiel - 25 septembre 2026.

## Installation recommandee

1. Extraire le ZIP si necessaire. Reperer sage-x3-4gl-1.1.0.vsix.
2. Dans VS Code, ouvrir les Extensions (Ctrl+Maj+X sous Windows/Linux), puis le
   menu ... et choisir Install from VSIX... (Installer a partir d'un VSIX...).
   La commande Extensions: Install from VSIX est aussi accessible via Ctrl+Maj+P.
3. Selectionner le fichier VSIX. Recharger la fenetre si VS Code le demande.
4. Ouvrir Exemple.src. Le mode de langage doit etre Sage X3 4GL, en bas a droite.
   Sinon, cliquer sur le mode actuel et choisir Sage X3 4GL.

Installation par terminal, lorsque la commande code est disponible :

```sh
code --install-extension sage-x3-4gl-1.1.0.vsix
```

Aucun npm, compte Marketplace ou serveur Sage n'est necessaire pour installer le
VSIX. L'identifiant x3-local.sage-x3-4gl est un identifiant technique local, pas
la preuve d'un editeur verifie. Le VSIX n'est pas signe et n'est pas publie au
Marketplace. Respecter les restrictions d'installation de votre organisation.

La compatibilite declaree commence a VS Code bureau 1.85 (Windows/macOS/Linux).
L'interface de ces plateformes n'a pas ete testee ici. Pas de cible vscode.dev
pour les fonctionnalites JavaScript de cette version.

## Ce qui est inclus

- Coloration TextMate : mots-cles, fonctions avec $, variables, classes,
  champs, etiquettes, commentaires #, chaines, dates et nombres.
- 583 completions statiques avec statut et provenance ; arguments modifiables
  pour une selection de fonctions courantes, pas toutes les signatures Sage.
- 39 snippets, chacun avec deux prefixes : le prefixe simple et x3 + prefixe.
- Survol des noms du catalogue pour afficher le statut et les references.
- Etiquettes $... et declarations Subprog/Funprog/Method du fichier courant
  dans le panneau Outline/Plan et dans les suggestions. Il s'agit d'un releve
  lexical, pas d'une resolution inter-fichiers ni d'une validation semantique.
- Commentaires #, parentheses et crochets, indentation de base et repli par
  indentation. Les marqueurs #region / #endregion sont pris en charge.

Extensions associees : .src, .stc, .spe, .x3 et .4gl. Ces extensions peuvent
appartenir a d'autres langages. En cas de conflit, choisir le mode de langage
manuellement ou ajuster files.associations dans le projet, sans association globale.

## Utiliser les snippets et completions

Dans un fichier reconnu Sage X3 4GL, saisir x3read, puis Ctrl+Espace, choisir
Sage X3 - read et valider. Tab passe au champ suivant ; Maj+Tab revient au precedent.
Les prefixes Read, For, Case, Gosub, Call et Local File sont respectivement
read, for, case, gosub, call et localfile (ou x3read, x3for, etc.).

Les prefixes simples peuvent aussi proposer le mot-cle seul. Choisir le snippet
pour obtenir le bloc complet, ou utiliser le prefixe x3... pour lever l'ambiguite.
Pour l'insertion directe par Tab, activer editor.tabCompletion dans les reglages :

```json
{"editor.tabCompletion": "on"}
```

Autre methode : commande Insert Snippet / Inserer un extrait dans la palette.
La liste complete est dans SNIPPETS_FR.md. Les noms tels que num$ et date$ gardent
leur dollar litteral ; les etiquettes $ACTION ne deviennent pas des variables
internes du moteur de snippets.

Dans les parametres Sage X3 4GL, includeInternal et includeDeprecated permettent
de masquer les suggestions internes ou anciennes sans retirer leur coloration.
La couleur exacte depend du theme VS Code. L'extension ne remplace pas le theme.

## Confidentialite et maintenance

Le code de l'extension ne fait aucun appel reseau, ne lance aucun processus et
ne se connecte pas a Sage. Il lit le catalogue embarque et le document edite.
Les liens de documentation ne s'ouvrent que sur action de l'utilisateur.

Les sources modifiables sont incluses dans le ZIP. Pour les tester, ouvrir le
dossier sources dans VS Code et appuyer sur F5. Pour les tests unitaires, utiliser
node tests/test_core.js (Node.js requis uniquement pour le developpement).
Une installation de vsce peut ensuite reconstruire le VSIX avec :

```sh
npx @vscode/vsce package --no-dependencies --allow-missing-repository
```

Le VSIX fourni a ete assemble hors ligne dans la structure de paquet VSIX ; il
n'a pas ete produit par vsce dans cet environnement. Voir TESTS_FR.md.

## Documentation de l'editeur

- [Installer un VSIX](https://code.visualstudio.com/docs/configure/extensions/extension-marketplace#_install-from-a-vsix).
- [Coloration TextMate](https://code.visualstudio.com/api/language-extensions/syntax-highlight-guide).
- [Snippets](https://code.visualstudio.com/docs/editing/userdefinedsnippets).
- [Configuration de langage](https://code.visualstudio.com/api/language-extensions/language-configuration-guide).

## Perimetre et limites

Le catalogue est celui du package Sublime fourni : 571 noms moteur documentes,
8 globales applicatives et 4 exemples de variables de contexte. Les statuts
public, nouveau, ancien et interne restent distincts dans le catalogue.
La cible est la documentation Sage X3 v12 consultee le 25 septembre 2026, pas
une garantie de compatibilite avec tous les correctifs ou toutes les versions.
Les anomalies du glossaire sont conservees dans catalogue.json ; aucun nom
manquant n'a ete invente. La phrase Order By reste reconnue par la coloration.

GUSER, GACTX, GERR et GFONCTION sont des identifiants applicatifs, pas des mots
reserves du moteur. Leur disponibilite depend du dossier et du contexte.
GFONCTION est repris a la demande de l'utilisateur ; sa definition officielle
n'est pas verifiee dans ce catalogue. Les etiquettes peuvent etre personnalisees.

Aucun compilateur, controle de types, validation des tables/index/parametres,
connexion au serveur, deploiement, execution ou debogueur Sage n'est inclus.
Les exemples et modeles sont des aides de saisie a adapter avant execution.
Conserver l'encodage et les fins de ligne de vos traitements existants.

## Sources et provenance

- Source de conversion : Sage_X3_4GL_Sublime_Text.zip fourni dans la conversation.
- [Glossaire des mots-cles Sage X3](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_x3script-keywords-glossary.html).
- Voir CATALOGUE.md et catalogue.json (data/catalogue.json dans les sources VS Code)
  pour les categories, statuts, sources supplementaires et anomalies.
- Ce package local n'est pas publie, certifie ou maintenu officiellement par Sage,
  Microsoft, Sublime Text ou Notepad++.
