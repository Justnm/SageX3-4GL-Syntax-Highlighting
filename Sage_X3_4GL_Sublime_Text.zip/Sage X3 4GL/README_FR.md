# Sage X3 4GL pour Sublime Text

**Version 1.0.0 - Documentation consultée le 25 septembre 2026**  
Cible : **Sublime Text 4**, Windows, macOS ou Linux.

Package indépendant de coloration et d'aide à la saisie. Il ne s'agit pas d'un
produit officiel Sage ni d'un compilateur X3. Aucun plugin Python, aucune
connexion au serveur et aucune dépendance à installer pour l'utiliser.

## Installation conseillée : archive ZIP

1. Dans Sublime Text, ouvre **Preferences > Browse Packages...**.
2. Extrais le ZIP et copie son dossier **Sage X3 4GL** dans le dossier **Packages**
   qui vient de s'ouvrir. Copie le dossier entier, pas seulement le fichier de syntaxe.
3. Ouvre un fichier `.src`, puis choisis **View > Syntax > Sage X3 4GL**.
   Si le langage n'apparaît pas, redémarre Sublime Text.

Structure attendue :

```text
Packages/
  Sage X3 4GL/
    Sage X3 4GL.sublime-syntax
    Sage X3 4GL.sublime-completions
    Sage X3 4GL.sublime-settings
    Snippets/
    ...
```

**Ancienne version :** sauvegarde ton ancien package en dehors du dossier
Packages avant de le remplacer. Une copie laissée dans Packages peut charger
une deuxième définition du langage. Il ne doit pas y avoir deux dossiers
`Sage X3 4GL` imbriqués.

Le fichier `Exemple.src` sert à vérifier la coloration. Ce n'est pas un
programme universel à exécuter : les tables, index et contextes doivent
correspondre à ton dossier Sage X3.

## Autre installation : archive .sublime-package

Le fichier **Sage X3 4GL.sublime-package** contient les mêmes ressources, sans
le dossier racine du ZIP. Place-le dans **Installed Packages**, le dossier situé
à côté de **Packages** dans le dossier de données de Sublime Text.
Conserve le nom du fichier. Utilise une seule des deux méthodes d'installation.
La méthode ZIP est plus pratique pour modifier les fichiers et lancer le test de syntaxe fourni.

## Contenu et périmètre

Le catalogue contient **571 noms distincts** : **566** noms non vides du tableau
Sage *X3 script keywords glossary*, et **5 compléments** documentés ailleurs :
`Boolean`, `TRUE`, `FALSE`, `compressfiles` et `SetInstancenosys`.
Les doublons de casse et de catégorie sont fusionnés. Les documents
sources et les anomalies du tableau sont conservés dans `catalogue.json`.

Il s'agit d'une couverture de cet instantané de documentation X3 v12,
pas d'une promesse couvrant tous les patchs, versions passées/futures,
API métier, sous-programmes du standard ou développements spécifiques.

Le package fournit :

- La coloration des instructions, types, fonctions, variables du moteur,
  classes, champs, labels, chaînes, commentaires `#`, dates, nombres et opérateurs.
- **583 complétions** : 571 noms du catalogue, 8 globales applicatives et
  4 exemples de variables de contexte. Les fonctions usuelles ont des champs
  d'arguments ; les autres entrées insèrent le nom sans inventer leur signature.
- **39 snippets**, avec champs modifiables et réutilisation des noms saisis.
- La configuration du commentaire `#`, une indentation de base et des scopes
  de symboles pour les déclarations de routines et de labels.

Les catégories se chevauchent : 111 noms de variables/méthodes du moteur,
255 noms d'instructions, 208 noms de fonctions et 2 constantes ajoutées.
Il ne faut donc pas additionner ces nombres pour obtenir le total unique.

### Statuts officiels

Les complétions affichent le statut du catalogue : public, introduit en V7+,
ancien/Classic, obsolète Classic ou interne. Tous restent reconnaissables
pour lire du code existant. **La présence d'un nom dans la liste n'est pas
une recommandation d'utiliser une fonction interne ou obsolète.**
Les couleurs sont fournies par ton thème ; les statuts sont indiqués dans
les annotations de complétion, pas par une couleur imposée.

### Fonctions contenant $

Exemples : `num$`, `date$`, `datetime$`, `left$`, `right$`, `mid$`, `seg$`,
`format$`, `gdat$`, `time$`, `string$`, ainsi que `find`, `type`, `len`, `instr`,
`val`, `clalev`, `nbrecord`, etc.

`date$` est proposé sans parenthèses. Le second argument de `right$`
est la **position de départ**, pas le nombre de caractères à conserver.
Les dollars littéraux sont échappés dans les ressources de complétion
et de snippets pour ne pas être interprétés comme des variables Sublime.

### Variables et classes

Variables du moteur : `fstat`, `adxlog`, `adxifs`, `adxirs`, `adxium`,
`currind`, `nolign`, `status`, etc. Les anciens noms conservent leur statut.

Globales applicatives : `GUSER`, `GACTX`, `GERR`, `GFONCTION`, `GMESSAGE`,
`GPE`, `GMENDEP` et `GUSRAUZ`.

Ces globales ne sont pas des mots réservés du moteur. Leur disponibilité
et leur sens dépendent du contexte et du dossier. `GFONCTION` est inclus
à la demande de l'utilisateur ; aucune définition officielle n'a été
vérifiée pour ce nom pendant cette préparation. Le package ne déclare
ni n'initialise ces variables. Il ne classe pas arbitrairement tous les
identifiants commençant par G comme des variables système.

Exemples reconnus :

```text
[F:BPC]BPCNUM
[M:SOH0]SOHNUM
[L]MA_VARIABLE
[V]GUSER
[S]fstat
[G:BPC]currind
[BPC]BPC0
[F:]
[M:]
```

Les formes `[F:]` et `[M:]` sont tolérées pour faciliter la saisie en
cours ; la coloration ne certifie pas qu'une instruction incomplète est valide.
Les identifiants `CST_...` ont une coloration par convention de nommage,
sans vérification de leur déclaration réelle.

### Labels

`$ACTION`, `$OUVRE`, `$LIENS`, `$RAZCRE` et les labels personnalisés
sont reconnus sans imposer de deux-points. Les labels nus déclarés sur
une ligne seule ou avant `:` sont aussi reconnus, hors mots réservés.
Les références après `Gosub`, `Goto` et `Onerrgo` sont distinguées
des déclarations.

## Utiliser les snippets

Dans un fichier dont la syntaxe est **Sage X3 4GL**, saisis un déclencheur
ci-dessous, puis appuie sur **Tab**. Si plusieurs suggestions sont présentes,
sélectionne l'entrée **Sage X3 - ...** correspondant au snippet.
Utilise **Tab** pour passer au champ suivant et **Shift+Tab** pour revenir.

| Déclencheur | Contenu |
|---|---|
| `read` | `Read` avec branchement sur `fstat` |
| `for` | Boucle numérique `For` / `Next` |
| `forstep` | Boucle numérique avec `Step` |
| `fordb` | Parcours d'une table déjà ouverte |
| `case` | `Case`, `When` et `When Default` |
| `gosub` | Appel d'un label local |
| `gosubfrom` | Appel d'un label d'un autre traitement |
| `call` | Appel externe `Call ... From ...` |
| `calllocal` | Appel `Call` dans le même traitement |
| `localfile` | `Local File TABLE [ABR]` |
| `subprog` | Sous-programme avec argument entier, terminé par `End` |
| `funprog` | Fonction avec argument entier et valeur retournée |
| `func` | Appel de fonction avec nom du traitement |
| `label` | Label personnalisé avec `Return` |
| `action` | `$ACTION` avec `$OUVRE`, `$LIENS` et `$RAZCRE` |
| `if`, `ifelse` | Conditions |
| `while`, `repeat` | Boucles |
| `filter` | Filtre sur une table ouverte |
| `localchar`, `localint` | Déclarations de variables |
| `classf`, `classm`, `classl`, `classv`, `classs` | Références de classes |

Snippets supplémentaires de labels : `labelouvre`, `labelliens`,
`labelrazcre`, `labelferme`, `labelverif`, `labelcreation`, `labelmodif`,
`labelannule`, `labelapres_cre`, `labelapres_mod`, `labelavant_cre`,
`labelavant_mod`.

**Rappels importants :** déclare les compteurs utilisés par les boucles,
ouvre les tables avant les accès, et adapte les types des arguments des
sous-programmes. `Subprog` se termine par `End`, `Funprog` par `End VALEUR`,
alors qu'une routine appelée par `Gosub` se termine par `Return`.
Le snippet `read` ne suppose pas que tout `fstat` non nul signifie
simplement « client absent ».

## Fichiers et personnalisation

- `Sage X3 4GL.sublime-syntax` : règles de coloration et groupes de mots.
- `Sage X3 4GL.sublime-completions` : suggestions, arguments usuels et statuts.
- `Sage X3 4GL.sublime-settings` : indentation, complétion et gestion de `$`.
- `Snippets/` : un fichier XML par snippet, directement modifiable.
- `Comments.tmPreferences`, `Indentation.tmPreferences`, `Symbols.tmPreferences` : préférences du langage.
- `Exemple.src` : fichier de démonstration.
- `catalogue.json`, `CATALOGUE.md`, `coverage.json` : inventaire et traçabilité.
- `syntax_test_sage_x3.src`, `TESTS.md`, `test-report.json` : tests et limites de validation.

Les extensions associées sont `.src`, `.stc`, `.spe`, `.x3` et `.4gl`.
Les associations `.spe`, `.x3` et `.4gl` sont des commodités du package,
pas une affirmation sur les formats officiels du moteur X3.
Ne pas utiliser le package pour lire ou modifier des fichiers compilés `.adx`.
Pour une extension partagée avec un autre langage, choisis explicitement
**Sage X3 4GL** dans le menu Syntax du fichier concerné.

`catalogue.json` est un inventaire, pas un fichier chargé dynamiquement
par Sublime. Modifier cet inventaire seul ne change pas la coloration.
Pour ajouter une globale personnalisée, ajoute son nom au groupe
`application_globals` du fichier de syntaxe et ajoute une entrée dans
le fichier `.sublime-completions`. Pour ajouter un modèle de code,
duplique un fichier de `Snippets/` en changeant son `tabTrigger`.

## Tests et limites

Les fichiers YAML, JSON, XML et plist ont été analysés. Les 45 expressions
régulières développées ont été compilées avec Python et Ruby.
Un scanner lexical indépendant a contrôlé les 571 noms sous quatre
formes de casse, les frontières des identifiants et des cas de régression.
Les ressources de snippets et de complétion ont été contrôlées
pour la conservation des dollars littéraux.

**Non effectué ici :** lancement du package dans Sublime Text,
contrôle visuel dans ses thèmes, compilation ou exécution sur Sage X3.
Les contrôles statiques ne remplacent pas ces tests d'intégration.

Pour le test natif, installe par la méthode ZIP, ouvre
`syntax_test_sage_x3.src`, puis lance **Tools > Build** avec le système
de build automatique. Sublime reconnaît le préfixe `syntax_test_` et
la ligne `SYNTAX TEST`. Ce fichier vérifie les scopes, pas l'exécution X3.

Ce package ne fournit ni compilateur, ni débogueur, ni serveur de langage,
ni validation des signatures, ni consultation automatique des dictionnaires
X3. La complétion des champs d'une table en fonction de ton dossier
n'est pas implémentée. Les chaînes sont traitées de façon lexicale,
avec reprise à la ligne suivante lorsqu'un guillemet est inachevé.
Les mots du catalogue sont reconnus sans tenir compte de la casse.

## Sources

Noms, catégories et statuts du langage :

- [Sage X3 - X3 script keywords glossary](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_x3script-keywords-glossary.html)
- [Sage X3 - Glossary](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_glossary.html)
- [Sage X3 - Boolean](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_boolean.html)

Formes de langage utilisées dans les snippets :

- [Read](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_read.html)
- [For](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_for.html)
- [Case](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_case.html)
- [File](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_file.html)
- [Gosub](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_gosub.html)
- [End](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_end.html)
- [Right$](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_right%24.html)

Format des ressources Sublime :

- [Syntax Definitions](https://www.sublimetext.com/docs/syntax.html)
- [Completions et snippets](https://www.sublimetext.com/docs/completions.html)
- [Packages](https://www.sublimetext.com/docs/packages.html)

Les liens propres aux globales et les anomalies de la documentation sont
précisés dans `catalogue.json`. La documentation Sage n'est pas reproduite
intégralement : le catalogue conserve les identifiants du langage et leurs
classifications. Sage X3 et Sublime Text sont les marques de leurs titulaires.
