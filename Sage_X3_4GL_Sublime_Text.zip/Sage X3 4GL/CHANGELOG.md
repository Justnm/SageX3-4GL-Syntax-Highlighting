# Historique

## 1.0.0 - 2026-09-25

Première livraison : catalogue documenté de 571 noms, 583 complétions,
39 snippets, classes et champs, labels, commentaires, préférences et
fichier de test natif. Correction des labels sans deux-points, des noms de
fonctions terminés par `$`, des opérateurs composés et des snippets
Subprog terminés par End.
