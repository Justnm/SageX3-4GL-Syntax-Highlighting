# Rapport de contrôles - 25 septembre 2026

## Résultat

Les contrôles statiques ont réussi. Le rapport détaillé est dans
`test-report.json`.

- Structure YAML, JSON, XML et plist.
- Compilation de 45 règles regex après expansion des variables.
- Couverture des 571 noms sous quatre formes de casse.
- Absence de reconnaissance partielle dans des identifiants plus longs.
- Labels sans deux-points, classes et champs, dollars de fonctions,
  opérateurs composés et plages `1..10`.
- Conservation des dollars littéraux dans les snippets et complétions.
- Positionnement des assertions du fichier de test natif fourni.

Le total de 17 592 assertions inclut des vérifications caractère par
caractère ; ce n'est pas un nombre de scénarios utilisateurs distincts.

## Limites

Le scanner utilisé pour ces contrôles est indépendant. Il prend en
charge le sous-ensemble de contextes présent dans cette syntaxe. La
compilation regex Ruby est une vérification complémentaire, pas
l'exécution du moteur Sublime.

Le package n'a pas été lancé dans Sublime Text dans cet environnement.
Aucun exemple n'a été compilé ou exécuté sur un serveur Sage X3.

Après installation par le ZIP, ouvrir `syntax_test_sage_x3.src` dans
Sublime et lancer `Tools > Build` pour effectuer les assertions natives
sur les scopes. Ouvrir `Exemple.src` pour le contrôle visuel, puis essayer
`read`, `localfile` et `action` suivis de Tab dans un nouveau fichier `.src`.
