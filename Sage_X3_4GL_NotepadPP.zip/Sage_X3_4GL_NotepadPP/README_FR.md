# Sage X3 4GL pour Notepad++

Version 1.1.0 - package local non officiel - 25 septembre 2026.
Cible : Notepad++ 8.x sous Windows, systeme UDL 2.1.

## 1. Installer la coloration

Extraire le ZIP. Dans Notepad++, ouvrir Language > User Defined Language >
Define your language... (Langage > Langage utilisateur > Definir votre langage...).
Cliquer Import... et choisir UN SEUL des fichiers suivants :

- UDL/Sage_X3_4GL_Clair.xml pour un fond clair.
- UDL/Sage_X3_4GL_Sombre.xml pour un fond sombre.

Les deux fichiers utilisent volontairement le meme nom de langage : Sage X3 4GL.
Ne pas importer les deux a la fois. Si une ancienne definition porte deja ce nom,
l'exporter pour sauvegarde puis la supprimer dans cette boite de dialogue avant
l'import. Pour changer de variante, remplacer l'ancienne de la meme maniere.

Fermer puis relancer Notepad++, ouvrir Exemple.src et choisir Langage > Sage X3 4GL
si necessaire. Le champ Ext. contient src stc spe x3 4gl (sans point).
Les fichiers .src peuvent appartenir a d'autres langages : ajuster ce champ en
cas de conflit. Ne pas remplacer entierement un fichier userDefineLang.xml existant.

## 2. Installer l'autocompletion

Copier le fichier autoCompletion/Sage X3 4GL.xml de ce ZIP dans le sous-dossier
autoCompletion du DOSSIER D'INSTALLATION de Notepad++, a cote de notepad++.exe.
Exemple pour une installation Windows standard :

```text
C:\Program Files\Notepad++\autoCompletion\Sage X3 4GL.xml
```

Pour une version portable, utiliser le dossier autoCompletion de cette version.
Ce fichier NE doit PAS etre copie dans %APPDATA%\Notepad++\autoCompletion :
ce n'est pas l'emplacement de ces definitions selon le manuel Notepad++.
Une autorisation Windows peut etre requise pour copier dans Program Files.
Sauvegarder toute ancienne definition du meme nom avant remplacement.

Redemarrer Notepad++. Ouvrir Settings > Preferences > Auto-Completion
(Parametrage > Preferences > Auto-completion), activer la completion et choisir
Function and word completion (fonctions et mots), puis l'aide aux parametres.
Ctrl+Espace declenche manuellement la liste ; Ctrl+Maj+Espace demande les parametres.

Le fichier contient 601 entrees triees sans tenir compte de la casse : les noms
du catalogue compatibles avec ce format, les globales, variables de contexte,
13 etiquettes et 6 references de classe. Order By contient un espace : il n'est
pas insere comme entree unique ; Order et By sont deja presents separement.
La coloration et le catalogue conservent bien la phrase complete.

Pour faciliter les noms avec $, aller aussi dans Settings > Preferences >
Delimiters et ajouter $ aux caracteres faisant partie d'un mot, sans supprimer
vos reglages existants. Ce reglage est global. Le XML declare aussi $[]: comme
caracteres supplementaires pour les noms.

IMPORTANT : le manuel Notepad++ ne garantit pas les bulles de parametres pour
les noms contenant de la ponctuation. num$, left$, right$, date$, etc. figurent
bien dans la completion, mais ne sont pas declares comme fonctions a calltip.
19 fonctions a nom simple ont une aide aux arguments configuree. Consulter
FONCTIONS_FR.md pour les formes de saisie, y compris les fonctions contenant $.

## 3. Utiliser les 39 modeles

Le dossier Modeles contient les equivalences des 39 snippets Sublime. Exemples :
read.src, for.src, fordb.src, case.src, gosub.src, call.src, localfile.src,
subprog.src, funprog.src et action.src.

Ouvrir le modele voulu dans Notepad++, copier le bloc utile et adapter les noms,
types, parametres, tables et cles. SNIPPETS_FR.md sert d'index.

Ces fichiers sont des modeles a copier. Ce package n'installe pas de moteur de
snippets a tabulations dans Notepad++ et ne pretend pas reproduire l'expansion
Tab de VS Code. Aucun plugin tiers n'est requis pour coloration et completion.

## Differences de coloration par rapport a VS Code

UDL utilise huit groupes de mots-cles et des delimiteurs, pas la grammaire
TextMate fournie a VS Code. Toutes les categories sont insensibles a la casse.

- Les noms commencant par $ sont colores comme etiquettes ; les noms CST_...
  ont une mise en evidence par prefixe. Ce n'est pas une validation de leur usage.
- Le contenu entre [ et ] a un style commun : il couvre les classes [F:BPC],
  [M:SOH0], [L], [V], [S] mais aussi les indices et litteraux de date entre crochets.
  UDL ne differencie pas chaque cas comme la grammaire VS Code.
- Le champ apres une classe, comme BPCNUM dans [F:BPC]BPCNUM, reste un identifiant
  ordinaire ; la reference entre crochets est mise en evidence.
- Le repli de blocs est lexical et approximatif. Return n'est pas utilise comme
  fermeture universelle : cela casserait les blocs ou les routines imbriques.
- Le theme UDL n'est pas automatiquement adapte lors d'un changement de theme
  Notepad++ ; utiliser la variante claire ou sombre appropriee.

Aucune installation dans une interface Notepad++ n'a ete executee ici.
Voir TESTS_FR.md pour les validations statiques et leurs limites.

## Documentation de l'editeur

- [Manuel UDL](https://npp-user-manual.org/docs/user-defined-language-system/).
- [Manuel autocompletion](https://npp-user-manual.org/docs/auto-completion/).
- [Sources du manuel autocompletion](https://github.com/notepad-plus-plus/npp-usermanual/blob/master/content/docs/auto-completion.md).

## Perimetre et limites

Le catalogue est celui du package Sublime fourni : 571 noms moteur documentes,
8 globales applicatives et 4 exemples de variables de contexte. Les statuts
public, nouveau, ancien et interne restent distincts dans le catalogue.
La cible est la documentation Sage X3 v12 consultee le 25 septembre 2026, pas
une garantie de compatibilite avec tous les correctifs ou toutes les versions.
Les anomalies du glossaire sont conservees dans catalogue.json ; aucun nom
manquant n'a ete invente. La phrase Order By reste reconnue par la coloration.

GUSER, GACTX, GERR et GFONCTION sont des identifiants applicatifs, pas des mots
reserves du moteur. Leur disponibilite depend du dossier et du contexte.
GFONCTION est repris a la demande de l'utilisateur ; sa definition officielle
n'est pas verifiee dans ce catalogue. Les etiquettes peuvent etre personnalisees.

Aucun compilateur, controle de types, validation des tables/index/parametres,
connexion au serveur, deploiement, execution ou debogueur Sage n'est inclus.
Les exemples et modeles sont des aides de saisie a adapter avant execution.
Conserver l'encodage et les fins de ligne de vos traitements existants.

## Sources et provenance

- Source de conversion : Sage_X3_4GL_Sublime_Text.zip fourni dans la conversation.
- [Glossaire des mots-cles Sage X3](https://online-help.sagex3.com/erp/12/en-us/Content/V7DEV/4gl_x3script-keywords-glossary.html).
- Voir CATALOGUE.md et catalogue.json (data/catalogue.json dans les sources VS Code)
  pour les categories, statuts, sources supplementaires et anomalies.
- Ce package local n'est pas publie, certifie ou maintenu officiellement par Sage,
  Microsoft, Sublime Text ou Notepad++.
