# Aide aux arguments

Les noms contenant `$` sont proposes pour la completion mais les bulles de parametres ne sont pas garanties par Notepad++. Les formes ci-dessous sont des aides de saisie reprises du package fourni, pas un inventaire exhaustif des signatures.

| Nom | Forme proposee | Bulle de parametres configuree |
|---|---|---|
| `abs` | `abs(NOMBRE)` | Oui |
| `addmonth` | `addmonth(DATE, NOMBRE_MOIS)` | Oui |
| `arr` | `arr(NOMBRE, PAS)` | Oui |
| `chr$` | `chr$(CODE)` | Non : nom avec ponctuation |
| `clalev` | `clalev([BPC])` | Oui |
| `day` | `day(DATE)` | Oui |
| `eomonth` | `eomonth(DATE)` | Oui |
| `find` | `find(VALEUR, LISTE)` | Oui |
| `format$` | `format$(FORMAT, VALEUR)` | Non : nom avec ponctuation |
| `gdat$` | `gdat$(JOUR, MOIS, ANNEE)` | Non : nom avec ponctuation |
| `instr` | `instr(POSITION_DEBUT, TEXTE, RECHERCHE)` | Oui |
| `left$` | `left$(TEXTE, NOMBRE_CARACTERES)` | Non : nom avec ponctuation |
| `len` | `len(TEXTE)` | Oui |
| `mid$` | `mid$(TEXTE, POSITION_DEBUT, LONGUEUR)` | Non : nom avec ponctuation |
| `mod` | `mod(NOMBRE, DIVISEUR)` | Oui |
| `month` | `month(DATE)` | Oui |
| `nbrecord` | `nbrecord([BPC])` | Oui |
| `num$` | `num$(VALEUR)` | Non : nom avec ponctuation |
| `right$` | `right$(TEXTE, POSITION_DEBUT)` | Non : nom avec ponctuation |
| `rowcount` | `rowcount([BPC])` | Oui |
| `seg$` | `seg$(TEXTE, POSITION_DEBUT, POSITION_FIN)` | Non : nom avec ponctuation |
| `space$` | `space$(NOMBRE)` | Non : nom avec ponctuation |
| `string$` | `string$(NOMBRE, TEXTE)` | Non : nom avec ponctuation |
| `tolower` | `tolower(TEXTE)` | Oui |
| `toupper` | `toupper(TEXTE)` | Oui |
| `type` | `type(VARIABLE)` | Oui |
| `val` | `val(TEXTE)` | Oui |
| `vireblc` | `vireblc(TEXTE, MODE)` | Oui |
| `year` | `year(DATE)` | Oui |
